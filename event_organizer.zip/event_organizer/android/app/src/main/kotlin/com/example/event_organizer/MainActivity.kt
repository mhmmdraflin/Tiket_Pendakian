package com.example.event_organizer

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
